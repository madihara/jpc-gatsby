import React from "react"

import styles from "../styles/trustedby.module.css"

const TrustedBy = () => {
  return <div className={styles.container}>Trusted By</div>
}

export default TrustedBy
