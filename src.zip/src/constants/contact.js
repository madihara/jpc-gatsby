export default [
  {
    name: "jpc, llc",
    phone: "+1 574 293 8030",
    street: "2926 Paul Dr",
    city: "elkhart",
    state: "indiana",
    abbreviation: "IN",
    zip: "46514",
  },
]
