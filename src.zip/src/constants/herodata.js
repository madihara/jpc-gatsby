export default [
  {
    title: "We specialize in commercial sewing",
    info: "Here at Jpc...",
  },
]
