export default [
  {
    path: "/",
    text: "home",
  },
  {
    path: "/capabilities",
    text: "capabilities",
  },
  {
    path: "/services",
    text: "services",
  },

  {
    path: "/portfolio",
    text: "portfolio",
  },

  {
    path: "/contact",
    text: "contact",
  },
]
