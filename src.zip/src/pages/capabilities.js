import React from "react"
import Layout from "../components/Layout"

const capabilities = () => {
  return <Layout> I am Capable</Layout>
}

export default capabilities
