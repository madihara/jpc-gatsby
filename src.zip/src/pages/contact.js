import React from "react"
import Layout from "../components/Layout"

const contact = () => <Layout>Contact us</Layout>

export default contact
