import React from "react"
import Layout from "../components/Layout"

const manufacturing = () => {
  return <Layout> I am Capable</Layout>
}

export default manufacturing
