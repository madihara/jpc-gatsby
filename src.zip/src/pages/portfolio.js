import React from "react"
import Layout from "../components/Layout"

const portfolio = () => {
  return <Layout> I am Portfolio</Layout>
}

export default portfolio
