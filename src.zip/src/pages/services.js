import React from "react"
import Layout from "../components/Layout"

const services = () => <Layout>Services Page</Layout>

export default services
